<?php
 session_start();
 if(isset($_SESSION['id'])){
   header('Location:dashboard.php');
 }
 ?>
<!doctype html>
<html lang="en">
 <head>
    <?php include 'includes/header.php'; ?>
 </head>
 <body class="text-white">
    <?php include 'includes/navigation.php';?>
	 <div class="container mb-5 my-4">
	    <div class="row">
		 <div class="col-md-7 mx-auto">
		    <div class="card">
			 <div class="card-header py-3 text-center">
			    <h3 class="text-primary">Register To Join Us</h3>
			  </div>
                <div class="card-body">			  
			   <div class="my-2 text-center">
			    <?php include 'functions/register.php';?>
			   </div>
		    <form action="register.php" method="post">
			  <div class="my-2">
			    <label for="name" class="text-dark">Full name</label>
			    <div class="input-group">
				 <span class="input-group-text"><i class="bi bi-person"></i></span>
				 <input type="text" name="name" class="border border-dark form-control" placeholder="Full name"/>
				</div>
			  </div>
			   <div class="my-2">
			    <label for="email" class="text-dark">Your Email Address</label>
			    <div class="input-group">
				 <span class="input-group-text"><i class="bi bi-envelope"></i></span>
				 <input type="email" name="email" class="border border-dark form-control" placeholder="Your email address"/>
				</div>
			  </div>
			   <div class="my-2">
			    <label for="username" class="text-dark">Username</label>
			    <div class="input-group">
				 <span class="input-group-text"><i class="bi bi-person-circle"></i></span>
				 <input type="text" name="username" class="border border-dark form-control" placeholder="Create Username"/>
				</div>
				 <div class="my-2">
			    <label for="password" class="text-dark">Password</label>
			    <div class="input-group">
				 <span class="input-group-text"><i class="bi bi-lock"></i></span>
				 <input type="password" name="password" class="border border-dark form-control" placeholder="Password"/>
				</div>
			  </div>
			  </div>
			  <div class="my-2 text-center">
			    <input type="submit" name="register" value="Register" class="btn btn-lg btn-primary"/>
			  </div>
			</form>
			<p class="text-dark">Already a member? <a href="login.php">Login Here</a></p>
			</div>
		 </div>
		 </div>
		</div>
	 </div>
<!-- JavaScript Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
 </body>
</html>
