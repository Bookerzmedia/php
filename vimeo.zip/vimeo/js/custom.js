$(document).ready(function(){
	$("#livesearch").keyup(function(){
	  var input = $(this).val();
      if(input !=""){
		 $.ajax({
			url:'functions/livesearch.php',
            method:'post',
            data:{'input':input},
            success:function(data){
				$("#search_results").html(data);
			}			
		 }); 
	  }else{
		  $("#search_results").css("display","none");
	  }  
	});
})