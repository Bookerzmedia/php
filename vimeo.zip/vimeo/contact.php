<?php 
session_start();
include 'functions/livesearch.php';
?>
<!doctype html>
<html lang="en">
 <head>
    <?php include 'includes/header.php'; ?>
 </head>
 <body>
    <?php include 'includes/navigation.php';?>
	 <div class="conatiner mt-5">
	    <div class="row mt-5">
		 <div class="col-md-7 mx-auto mt-5 border border-info py-5 rounded bg-dark">
		    <h1 class="text-center text-white">This is a contact Page</h1>
		 </div>
		</div>
	 </div>
	 <div class="container-fluid p-5 my-5 card card-body">
	 <div class="row">
	    <div class="col-md-10 mx-auto">
		    <div class="my-3">
			 <h2 class="text-center text-primary">Search Employees</h2>
			</div>
		  
		   <div class="input-group">
		    <input type="text" id="livesearch" class="form-control"/>
			<span class="input-group-text">Search Employees</span>
			 
		  </div>
		</div> 
	 </div>
	 <div class="row">
	    <div class="col-md-12 p-3" id="search_results">
		</div>
	 </div>
	</div>
	<!-- JavaScript Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
  <script src="js/custom.js"></script>
 </body>
</html>