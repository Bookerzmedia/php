<?php
 session_start();
 if(isset($_SESSION['id'])){
   header('Location:dashboard.php');
 }
 ?>
<!doctype html>
<html lang="en">
 <head>
    <?php include 'includes/header.php'; ?>
 </head>
 <body>
    <?php include 'includes/navigation.php';?>
	<div class="container my-5">
	 <div class="row">
	  <div class="col-md-6 mx-auto">
	    <div class="card"> 
		<div class="card-header">
		<h3 class="text-center">Login To Your Account</h3>
		</div>
		<div class="card-body my-4">
		  <div class="my-2 text-center">
		    <?php include 'functions/login.php';?>
		  </div>
		 <form action="login.php" method="post">
		    <div class="my-3">
			<label for="emailuser">Email or Username</label>
			<div class="input-group">
			 <span class="input-group-text"><i class="bi bi-person"></i></span>
			 <input type="text" name="emailuser" class="form-control border borde-dark" placeholder="Email or Username"/>
			</div>
			</div>
			<div class="my-3">
			<label for="password">Password</label>
			<div class="input-group">
			 <span class="input-group-text"><i class="bi bi-lock"></i></span>
			 <input type="password" name="password" class="form-control border borde-dark" placeholder="Password"/>
			</div>
			</div>
			<div class="my-3 text-center">
			 <input type="submit" name="login" value="Login" class="btn btn-lg btn-success form-control"/>
			  <a href="psf.php">Forgotten Password</a>
			</div>
		 </form>
		 <div class="my-2">
		    <p>Not Registered Yet? <a href="register.php">Register Here</a></p>
		 </div>
		</div>
		</div>
	  </div>
	 </div>
	</div>
   <!-- JavaScript Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
 </body>
</html>
