<?php 
session_start();
include 'functions/dbconnection.php';
 ?>
<!doctype html>
<html lang="en">
 <head>
    <?php include 'includes/header.php'; ?>
 </head>
 <body>
    <?php include 'includes/navigation.php';?>
	<div class="container-fluid mt-5">
	   <div class="row">
	    <div class="col-md-12 mx-auto">
		<div class="card card-body">
		  <div class="my-3 text-center">
		    <h3 class="text-success">Search Users Information</h3>
			<form action="index.php" method="post">
			 
			 <div class="input-group my-3">
			    <input type="text" class="form-control" name="term" placeholder="Enter search term"/>
				<span class="input-group-text">
				 <input type="submit" class="btn" name="search" value="Search Employees"/>
				</span>
			 </div>
			</form>
			<div class="my-3">
			 <?php include 'functions/search.php';?>
			</div>
		  </div>
		</div>
		</div>
	   </div>
	</div>
	
	<!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>  
 </body>
</html>