<?php
session_start();
 if(!isset($_SESSION['id'])){
   header('Location:login.php');
 }
?>
<!doctype html>
<html lang="en">
 <head>
    <?php include 'includes/header.php'; ?>
 </head>
 <body class="pb-5">
    <?php include 'includes/navigation.php';?>
	<div class="container mt-3">
	 <div class="row">
	    <div class="col-md-12 text-center mt-5">
		 <h1 class="fw-bold text-white">Edit Your user Account</h1>
		</div>
	 </div>
	 </div>
	 <div class="container">
	    <div class="row">
		 <div class="col-md-7 mx-auto">
		    <div class="card card-body">
			   <div class="my-2 text-center">
			    <?php include 'functions/edit.php';?>
			   </div>

			 <?php
			  if(isset($_SESSION['id'])){
				  $id = $_SESSION['id'];
				  $sql = "SELECT * FROM users WHERE usersID='$id'";
		          $query = $conn->query($sql);
		          while($row = $query->fetch_assoc()){
				 ?>
			  <form action="edit.php" method="post">
			  <div class="my-2">
			    <label for="name">Full name</label>
			    <div class="input-group">
				 <span class="input-group-text"><i class="bi bi-person"></i></span>
				 <input type="text" name="name" value="<?php echo $row['usersName']; ?>" class="border border-dark form-control" placeholder="Full name"/>
				</div>
			  </div>
			   <div class="my-2">
			    <label for="email">Your Email Address</label>
			    <div class="input-group">
				 <span class="input-group-text"><i class="bi bi-envelope"></i></span>
				 <input type="email" name="email" value="<?php echo $row['usersEmail']; ?>" class="border border-dark form-control" placeholder="Your email address"/>
				</div>
			  </div>
			   <div class="my-2">
			    <label for="username">Username</label>
			    <div class="input-group">
				 <span class="input-group-text"><i class="bi bi-person-circle"></i></span>
				 <input type="text" name="username" value="<?php echo $row['usersUsername']; ?>" class="border border-dark form-control" placeholder="Create Username"/>
				</div>
				 <div class="my-2">
			    <label for="password">Password</label>
			    <div class="input-group">
				 <span class="input-group-text"><i class="bi bi-lock"></i></span>
				 <input type="password" name="password" class="border border-dark form-control" placeholder="Password"/>
				</div>
			    </div>
			   </div>
			   <div class="my-2 text-center">
			    <input type="submit" name="edit" value="Save Changes" class="btn btn-lg btn-primary"/>
			  </div>
			  </form>
			  <?php
			   }
			  }
			?>
			</div>
		 </div>
		</div>
	 </div>
    <!-- JavaScript Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
 </body>
</html>
