<?php
session_start();
if(!isset($_SESSION['id'])){
  header('Location:login.php');
}
include 'functions/dbconnection.php';
?>
<!doctype html>
<html lang="en">
 <head>
    <?php include 'includes/header.php'; ?>
 </head>
 <body>
    <?php include 'includes/navigation.php';?>
    <div class="container mt-5">
	 <div class="row">
	    <div class="col-md-12">
		 <h3 class="text-center">Your Basic Account Details</h3>
		 <table class="table table-bordered border table-striped">
		    <thead>
			<tr>
			<th>User ID</th>
			<th>User Name</th>
			<th>User Email</th>
			<th>User Username</th>
			</tr>
			</thead>
			<tbody>
			<?php
			if(isset($_SESSION['id'])){
				$id = $_SESSION['id'];
				$sql = "SELECT * FROM users WHERE usersID='$id'";
				$query = $conn->query($sql);
				while($row = $query->fetch_assoc()){
					?>
					 <tr>
					    <td><?php echo $row['usersID']; ?></td>
						<td><?php echo $row['usersName']; ?></td>
						<td><?php echo $row['usersEmail']; ?></td>
						<td><?php echo $row['usersUsername']; ?></td>
					 </tr>
					<?php
				}
			}
			?>
			</tbody>
		 </table>
		</div>
	 </div>
	 <div class="row my-3">
	    <div class="col-md-6 my-3">
		 <a href="edit.php" class="btn btn-lg btn-success form-control">
		  <i class="bi bi-pencil"></i>
		  Edit Basic Account Details
		 </a>
		</div>
		<div class="col-md-6 my-3">
		<a href="delete.php" class="btn btn-lg btn-danger form-control">
		 <i class="bi bi-trash"></i>
		   Delete Your Account
		</a>
		</div>
	 </div>
	<div>
	<div class="container-fluid">
	<div class="row my-5">
	    <div class="col-md-12">
		<div class="card card-body">
		 <h3 class="text-center">Full Account Details</h3>
		   <?php
		   if(isset($_SESSION['id'])){
			   $userid = $_SESSION['user'];
			   $sql = "SELECT * FROM profile WHERE username='$userid'";
			   $query = $conn->query($sql);
			   while($profile = $query->fetch_assoc()){
		  ?>
		  <div class="my-2 text-center">
		    <h3><img src="<?php echo $profile['profile_image']; ?>" style="height:70px;width:70px;border-radius:50%;"/></h3>
		  </div>
		 <table class="table table-bordered table-striped">
			<tr>
			 <th>ID</th>
			 <td><?php echo $profile['profileID'];?></td>
			</tr>
			<tr>
			 <th>User ID</th>
			 <td><?php echo $profile['username'];?></td>
			</tr>
			<tr>
			 <th>Job</th>
			 <td><?php echo $profile['job']; ?></td>
			</tr>
			<tr>
			 <th>Gender</th>
			 <td><?php echo $profile['gender']; ?></td>
			</tr>
			<tr>
			 <th>Location</th>
			 <td><?php echo $profile['location'];?></td>
			</tr>
			<tr>
			 <th>About</th>
			 <td><?php echo $profile['about'];?></td>
			</tr>
		 </table>
		 <?php
			   }
		   }
		 ?>
		 <div class="my-2">
		    <a href="update.php" class="btn btn-lg btn-primary form-control">
			   <i class="bi bi-pencil"></i>
			   Edit Your Detailed Account
			</a>
		 </div>
		</div>
	 </div>
	</div>
	</div>
    <!-- JavaScript Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
 </body>
</html>
