  <meta charset="utf-8"/>
   <link href="css/custom.min.css" rel="stylesheet"/>
   <link href="css/bootstrap.min.css" rel="stylesheet"/>
   <title>User Profile Application</title>
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css">
   <meta name="viewport" content="width=device-width,initial-scale=1.0"/>