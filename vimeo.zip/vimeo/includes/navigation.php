<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
	 <div class="container">
	    <a href="index.php" class="navbar-brand"><h2><i class="bi bi-filetype-php"></i>PHP APPLICATION</h2></a>
	    <button class="navbar-toggler" data-bs-toggle="collpase" data-bs-target="#menu">
		<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collaspe navbar-collapse" id="menu">
		 <ul class="navbar-nav ms-auto">
		   <?php 
		     if(isset($_SESSION['id'])){
				 ?>
				 <li class="nav-item">
				    <a href="index.php" class="nav-link h4 text-white"><i class="bi bi-house"></i>Home</a>
				 </li>
				 <li class="nav-item">
				    <a href="contact.php" class="nav-link h4 text-white"><i class="bi bi-envelope"></i>Contact Us</a>
				 </li>
				 <li class="nav-item">
				    <a href="dashboard.php" class="nav-link h4 text-white"><i class="bi bi-person"></i>Dasboard</a>
				 </li>
				 <li class="nav-item">
				    <a href="logout.php" class="nav-link h4 text-white"><i class="bi bi-escape"></i>Logout</a>
				 </li>
				 <?php
			 }else{
				?>
                 <li class="nav-item">
				    <a href="index.php" class="nav-link h4 text-white"><i class="bi bi-house"></i>Home</a>
				 </li>
				 <li class="nav-item">
				    <a href="contact.php" class="nav-link h4 text-white"><i class="bi bi-envelope"></i>Contact Us</a>
				 </li>
				 <li class="nav-item">
				    <a href="register.php" class="nav-link h4 text-white"><i class="bi bi-key"></i>Register</a>
				 </li>
				 <li class="nav-item">
				    <a href="login.php" class="nav-link h4 text-white"><i class="bi bi-lock"></i>Login</a>
				 </li>
               <?php				
			 }
		   ?>
		 </ul>
		</div>
	 </div>
	</nav>