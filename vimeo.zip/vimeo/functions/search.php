<?php 
if(isset($_POST['search'])){
	 $term = $_POST['term'];
	 
	 if(empty($term)){
		 echo "<div class='alert alert-danger'>
		  <h5><strong>Error! </strong> Please enter search terms</h5>
		 </div>";
	 }else{
		 $sql = "SELECT * FROM employee WHERE EmpName LIKE '%$term%'";
		 $query = $conn->query($sql);
		  if($query->num_rows>0){
			 ?>
             <table class="table table-bordered table-striped">
                <thead>
				 <tr>
				    <th>Emp ID</th>
					<th>Emp Name</th>
					<th>Emp DOB</th>
					<th>Emp Join Date</th>
					<th>Prev Experience</th>
					<th>Emp Salaray</th>
					<th>Emp Address</th>
				 </tr>
				</thead>
				<tbody>
		    <?php
			 while($row = $query->fetch_assoc()){
				 echo "<tr>";
				 echo "<td>".$row['EmpId']."</td>";
				 echo "<td>".$row['EmpName']."</td>";
				 echo "<td>".$row['EmpBOD']."</td>";
				 echo "<td>".$row['EmpJoiningDate']."</td>";
				 echo "<td>".$row['PrevExperience']."</td>";
				 echo "<td>".$row['Salary']."</td>";
				 echo "<td>".$row['Address']."</td>";
				 echo "</tr>";
			 }
		   echo "</tbody>";
           echo "</table>";		   
		  }else{
			echo "<div class='alert alert-danger'>
		  <h5><strong>Error! </strong> No Search Results Found</h5>
		 </div>";  
		  }
	 }
 }
?>