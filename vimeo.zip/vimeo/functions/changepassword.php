<?php
if(isset($_POST['submit'])){
       $email = mysqli_real_escape_string($conn,$_POST['email']);
       $newpassword = mysqli_real_escape_string($conn,$_POST['password']);
	 if(empty($email)){
        echo "<div class='alert alert-danger'>
         <h5><strong>Error! </strong>Please enter your current email</h5>
        </div>";
     }else if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
        echo "<div class='alert alert-danger'>
        <h5><strong>Error! </strong>Please enter a valid email</h5>
       </div>"; 
     }else if(empty($newpassword)){
        echo "<div class='alert alert-danger'>
         <h5><strong>Error! </strong>Please enter new password</h5>
        </div>";
     }else if(strlen($newpassword)<6){
        echo "<div class='alert alert-danger'>
         <h5><strong>Error! </strong>Passwords should be at least 6 characters long</h5>
        </div>";
     }else{
        $sql = "SELECT * FROM users WHERE usersEmail ='$email'";
        $query = $conn->query($sql);
        if($query->num_rows>0){
            $pwdhashed = PASSWORD_HASH($newpassword,PASSWORD_DEFAULT);
          $sql = "UPDATE users SET usersPassword = '$pwdhashed' WHERE usersEmail='$email'";
          if($conn->query($sql)){
            echo "<div class='alert alert-success'>
              <h5><strong>Success! </strong>You have successfully saved the new password</h5>
               </div>";
          }else{
            echo "<div class='alert alert-danger'>
             <h5><strong>Error! </strong>We could not save your new password</h5>
           </div>";
          }
        }else{
            echo "<div class='alert alert-danger'>
         <h5><strong>Error! </strong>We could not find the email address</h5>
        </div>";
        }
     }
 }
