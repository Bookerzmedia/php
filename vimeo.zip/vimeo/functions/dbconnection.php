<?php
define('dbhost','localhost');
define('dbuser','root');
define('dbpass','');
define('dbname','vimeo');

$conn = new mysqli(dbhost,dbuser,dbpass,dbname);