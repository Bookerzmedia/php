<?php
 include 'dbconnection.php';
 if(isset($_POST['register'])){
	   $name = mysqli_real_escape_string($conn,$_POST['name']);
	   $email = mysqli_real_escape_string($conn,$_POST['email']);
	   $username = mysqli_real_escape_string($conn,$_POST['username']);
	   $password = mysqli_real_escape_string($conn,$_POST['password']);
	   
	    if(empty($name)){
			echo "<div class='alert alert-danger'>
			 <h5><strong>Error! </strong>Please enter your full name</h5>
			</div>";
		}else if(!preg_match('/^[a-zA-Z ]*$/',$name)){
			echo "<div class='alert alert-danger'>
			 <h5><strong>Error! </strong>Name should be letters only</h5>
			</div>";
		}elseif(empty($email)){
			echo "<div class='alert alert-danger'>
			 <h5><strong>Error! </strong>Please enter your email address</h5>
			</div>";
		}else if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
			echo "<div class='alert alert-danger'>
			 <h5><strong>Error! </strong>Please enter a valid email</h5>
			</div>";
		}else if(empty($username)){
			echo "<div class='alert alert-danger'>
			 <h5><strong>Error! </strong>Please enter a username</h5>
			</div>";
		}else if(!preg_match('/^[a-zA-Z0-9]*$/',$username)){
			echo "<div class='alert alert-danger'>
			 <h5><strong>Error! </strong>Please username can only be letters and numbers</h5>
			</div>";
		}else if(empty($password)){
			echo "<div class='alert alert-danger'>
			 <h5><strong>Error! </strong>Password is required</h5>
			</div>";
		}else if(strlen($password)<6){
			echo "<div class='alert alert-danger'>
			 <h5><strong>Error! </strong>Password should be at least 6 characters long</h5>
			</div>";
		}else{
			$sql = "SELECT * FROM users WHERE usersEmail='$email'";
			$query = $conn->query($sql);
			if($query->num_rows>0){
				echo "<div class='alert alert-danger'>
			 <h5><strong>Error! </strong>The email address is already in use.</h5>
			</div>";
			}else{
				$sql = "SELECT * FROM users WHERE usersUsername='$username'";
				$query = $conn->query($sql);
				if($query->num_rows>0){
					echo "<div class='alert alert-danger'>
			          <h5><strong>Error! </strong>The Username you chose is already in use.</h5>
			         </div>";
				}else{
					$pwdhash = PASSWORD_HASH($password,PASSWORD_DEFAULT);
					$sql = "INSERT INTO users(usersName,usersEmail,usersUsername,usersActive,usersPassword)
					 VALUES('$name','$email','$username','No','$pwdhash')";
					 $query = $conn->query($sql);
					 if($query ==1){
						$sqls = "INSERT INTO profile(username,job,gender,location,about,profile_image)
						VALUES('$username','Programmer','Male','New York','I love Computers','https://cdn.pixabay.com/photo/2022/11/22/16/31/wooden-pegs-7610106_960_720.jpg')"; 
						$querys = $conn->query($sqls);
						if($querys){
							echo "<div class='alert alert-success'>
							<h5><strong>Success! </strong>Registration successful. Check email to activate your account.</h5>
							</div>";
						}else{
							echo "<div class='alert alert-danger'>
							<h5><strong>Error! </strong>Registration unsuccessful.Re-submit</h5>
							</div>";
						}
					 } 
				}
			}
		}
		
		
 }