<?php 
include 'dbconnection.php';
if(isset($_POST['submit'])){
	$emailuser = $_POST['emailuser'];
	if(empty($emailuser)){
		echo "<div class='alert alert-danger'>
		 <h5><strong>Error! </strong>Please enter Email or Username</h5>
		</div>";
	}else{
		$sql = "SELECT * FROM users WHERE usersEmail='$emailuser' OR usersUsername='$emailuser'";
		$query = $conn->query($sql);
		if($query->num_rows>0){
		  header('Location:changepassword.php');
		}else{
			echo "<div class='alert alert-danger'>
			 <h5><strong>Error! </strong>Email address or Username does not exist</h5>
			</div>";
		}
	}
}