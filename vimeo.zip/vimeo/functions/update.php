<?php
 if(isset($_SESSION['user'])){
	if(isset($_POST['save'])){
	 $user= $_SESSION['user'];
	 $job = mysqli_real_escape_string($conn,$_POST['job']);
     $gender = mysqli_real_escape_string($conn,$_POST['gender']);
     $location = mysqli_real_escape_string($conn,$_POST['location']);
     $about = mysqli_real_escape_string($conn,$_POST['about']);
     $file = $_FILES['image'];
	 
	 if(empty($job)){
		 echo "<div class='alert alert-danger'>
		  <h5><strong>Error! </strong>Please enter your job.</h5>
		 </div>";
	 }else if(empty($gender)){
		echo "<div class='alert alert-danger'>
		  <h5><strong>Error! </strong>Please enter your gender.</h5>
		 </div>";
	 }else if(empty($location)){
		 echo "<div class='alert alert-danger'>
		  <h5><strong>Error! </strong>Please enter your location.</h5>
		 </div>";
	 }else if(empty($about)){
		 echo "<div class='alert alert-danger'>
		  <h5><strong>Error! </strong>Please enter something about yourself.</h5>
		 </div>";
	 }else if(empty($file)){
		 echo "<div class='alert alert-danger'>
		  <h5><strong>Error! </strong>Please upload your image.</h5>
		 </div>";
	 }else{
       $file_name = $file['name'];
	   $file_error = $file['error'];
	   $file_size = $file['size'];
	   $file_tmp_name = $file['tmp_name'];
	   $file_name_separate = explode('.',$file_name);
	   //$file_extention = strtolower($file_name_separate[1]);
	   $file_extension = strtolower(end($file_name_separate));
	   $allowedExtensions = array('jpeg','jpg','png');
	   if(in_array($file_extension,$allowedExtensions)){
		  if($file_error == 0){
			if($file_size<300000){
			if(file_exists($file_name)){
				  echo "<div class='alert alert-danger'>
		      <h5><strong>Error! </strong>The image you have chosen exists.</h5>
		     </div>";
			}else{
				$fileDestination = 'uploads/'.$file_name;
				move_uploaded_file($file_tmp_name,$fileDestination);
				$sql = "UPDATE profile SET 
				job='$job',
				gender='$gender',
				location='$location',
				about='$about',
				profile_image='$fileDestination'
				WHERE username='$user'";
                  $query = $conn->query($sql);				
				  if($query){
					 echo "<div class='alert alert-success'>
		               <h5><strong>Success! </strong>Profile Information saved successfully.</h5>
		              </div>";  
				  }else{
					   echo "<div class='alert alert-danger'>
		               <h5><strong>Error! </strong>Sorry.We could not save the data</h5>
		              </div>";
				  }
			}	
			}else{
				  echo "<div class='alert alert-danger'>
		      <h5><strong>Error! </strong>The image is too large.</h5>
		    </div>";
			}
		  }else{
			  echo "<div class='alert alert-danger'>
		      <h5><strong>Error! </strong>The image is faulty.</h5>
		    </div>";  
		  }
	   }else{
		echo "<div class='alert alert-danger'>
		  <h5><strong>Error! </strong>The image type you selected is not allowed.</h5>
		 </div>";   
	   }
   }
  }
 }else{
	 echo "<div class='alert alert-danger'>
	  <h4><strong>You are not allowed here.</strong></h4>
	 </div>";
  }