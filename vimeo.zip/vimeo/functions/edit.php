<?php
 include 'dbconnection.php';
if(isset($_SESSION['id'])){
 if(isset($_POST['edit'])){
	 $id = $_SESSION['id'];
  $name = mysqli_real_escape_string($conn,$_POST['name']);
  $email = mysqli_real_escape_string($conn,$_POST['email']);
  $username = mysqli_real_escape_string($conn,$_POST['username']);
  $password = mysqli_real_escape_string($conn,$_POST['password']);      		 
      if(empty($name)){
			echo "<div class='alert alert-danger'>
			 <h5><strong>Error! </strong>Please enter your full name</h5>
			</div>";
		}else if(!preg_match('/^[a-zA-Z ]*$/',$name)){
			echo "<div class='alert alert-danger'>
			 <h5><strong>Error! </strong>Name should be letters only</h5>
			</div>";
		}elseif(empty($email)){
			echo "<div class='alert alert-danger'>
			 <h5><strong>Error! </strong>Please enter your email address</h5>
			</div>";
		}else if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
			echo "<div class='alert alert-danger'>
			 <h5><strong>Error! </strong>Please enter a valid email</h5>
			</div>";
		}else if(empty($username)){
			echo "<div class='alert alert-danger'>
			 <h5><strong>Error! </strong>Please enter a username</h5>
			</div>";
		}else if(!preg_match('/^[a-zA-Z0-9]*$/',$username)){
			echo "<div class='alert alert-danger'>
			 <h5><strong>Error! </strong>Please username can only be letters and numbers</h5>
			</div>";
		}else if(empty($password)){
			echo "<div class='alert alert-danger'>
			 <h5><strong>Error! </strong>Password is required</h5>
			</div>";
		}else if(strlen($password)<6){
			echo "<div class='alert alert-danger'>
			 <h5><strong>Error! </strong>Password should be at least 6 characters long</h5>
			</div>";
		}else{
			$sql = "SELECT * FROM users WHERE usersEmail='$email'";
			$query = $conn->query($sql);
			if($query->num_rows>0){
				echo "<div class='alert alert-danger'>
			 <h5><strong>Error! </strong>You did not change your email.</h5>
			</div>";
			}else{
				$sql = "SELECT * FROM users WHERE usersUsername='$username'";
				$query = $conn->query($sql);
				if($query->num_rows>0){
					echo "<div class='alert alert-danger'>
			          <h5><strong>Error! </strong>Username was not changed.</h5>
			         </div>";
				}else{
					$pwdhash = PASSWORD_HASH($password,PASSWORD_DEFAULT);
					$sql =  "UPDATE users SET usersName='$name',usersEmail='$email',usersUsername='$username',usersPassword='$pwdhash' WHERE usersID='$id'";
					 if($conn->query($sql)){
						echo "<div class='alert alert-success'>
			             <h5><strong>Success! </strong>Registration successful. Check email to activate your account.</h5>
			           </div>"; 
					 }else{
						echo "<div class='alert alert-danger'>
			             <h5><strong>Error! </strong>Your registration was not successful. Please check</h5>
			             </div>"; 
					 }
				}
			}
		}
		
  }
}