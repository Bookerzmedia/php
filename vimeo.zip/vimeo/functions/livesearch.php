<?php
include 'dbconnection.php';
 if(isset($_POST['input'])){
	 $input = $_POST['input'];
	 if(empty($input)){
		 echo "<div class='alert alert-danger text-center'>
		  <h5><strong>Error! </strong>Please enter search keyword</h5>
		 </div>";
	    }else{
		 $sql = "SELECT * FROM employee WHERE EmpName 
		 LIKE '%$input%' OR EmpBOD LIKE '%$input%' OR EmpJoiningDate LIKE '%$input%'";
		 $query = $conn->query($sql);
		 if($query->num_rows>0){
			 ?>
			 <table class="table table-bordered table-striped">
			    <thead>
				 <tr>
				    <th>Emp ID</th>
					<th>Emp Name</th>
					<th>Emp DOB</th>
					<th>Emp Join Date</th>
					<th>Prev Experience</th>
					<th>Emp Salaray</th>
					<th>Emp Address</th>
				 </tr>
				</thead>
				<tbody>
			 <?php
			 while($row = $query->fetch_assoc()){
				echo "<tr>";
				 echo "<td>".$row['EmpId']."</td>";
				 echo "<td>".$row['EmpName']."</td>";
				 echo "<td>".$row['EmpBOD']."</td>";
				 echo "<td>".$row['EmpJoiningDate']."</td>";
				 echo "<td>".$row['PrevExperience']."</td>";
				 echo "<td>".$row['Salary']."</td>";
				 echo "<td>".$row['Address']."</td>";
				 echo "</tr>"; 
			 }
			 echo "</tbody>";
			 echo "</table>";
		 }else{
			 echo "<div class='alert alert-danger'>
		  <h5><strong>Error! </strong>Please enter search keyword</h5>
		 </div>"; 
		 }
	 }
 }