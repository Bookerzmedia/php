<?php
 include 'functions/dbconnection.php';
 
  if(isset($_POST['login'])){
	 $emailuser = mysqli_real_escape_string($conn,$_POST['emailuser']);
	 $password = mysqli_real_escape_string($conn,$_POST['password']);
	 
	 if(empty($emailuser)){
		echo "<div class='alert alert-danger'>
			 <h5><strong>Error! </strong>Please enter email or username</h5>
			</div>"; 
	 }else if(empty($password)){
		echo "<div class='alert alert-danger'>
			 <h5><strong>Error! </strong>Please enter your password</h5>
			</div>"; 
	 }else{
		 $sql = "SELECT * FROM users WHERE usersEmail='$emailuser' OR usersUsername='$emailuser'";
		 $query = $conn->query($sql);
		 if($query->num_rows>0){
			while($row = $query->fetch_assoc()){
				$usersActive = $row['usersActive'];
				if($usersActive != 'Yes'){
				echo "<div class='alert alert-danger'>
			      <h5><strong>Error! </strong>You have not activated your account yet.</h5>
			      </div>";	
				}elseif(PASSWORD_VERIFY($password,$row['usersPassword']) == FALSE){
				 echo "<div class='alert alert-danger'>
			      <h5><strong>Error! </strong>The password you entered is wrong.</h5>
			      </div>";	
				}else if(PASSWORD_VERIFY($password,$row['usersPassword']) == TRUE){
					session_start();
					$_SESSION['id'] = $row['usersID'];
					$_SESSION['user'] = $row['usersUsername'];
					header('Location:dashboard.php');
				}
			}  
		 }else{
			echo "<div class='alert alert-danger'>
			 <h5><strong>Error! </strong>Username or Email address you enetered is wrong.</h5>
			</div>"; 
		 }
	 }
  }