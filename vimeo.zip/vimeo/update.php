<?php
session_start();
if(!isset($_SESSION['id'])){
  header('Location:login.php');
}
include 'functions/dbconnection.php';
?>
<!doctype html>
<html lang="en">
 <head>
    <?php include 'includes/header.php'; ?>
 </head>
 <body>
    <?php include 'includes/navigation.php';?>
	<div class="container mt-3">
	 <div class="row">
	    <div class="col-md-12 text-center mt-1">
		 <h1 class="fw-bold text-white">Add/Edit Your Profile Account</h1>
		</div>
	 </div>
	 </div>
	 <div class="container">
	    <div class="row">
		 <div class="col-md-7 mx-auto">
		    <div class="card card-body">
			   <div class="my-2 text-center">
			    <?php include 'functions/update.php';?>
			   </div>
			   <?php
			   if(isset($_SESSION['user'])){
				  $user = $_SESSION['user'];
				  $sql = "SELECT * FROM profile WHERE username='$user'";
				  $query = $conn->query($sql);
				  while($users = $query->fetch_assoc()){
			   ?>
			   <form action="update.php" method="post" enctype="multipart/form-data">
			  <div class="my-2">
			    <label for="job">Job</label>
			    <div class="input-group">
				 <span class="input-group-text"><i class="bi bi-person"></i></span>
				 <input type="text" name="job" value="<?php echo $users['job']; ?>" class="border border-dark form-control" placeholder="Your Job"/>
				</div>
			  </div>
			   <div class="my-2">
			    <label for="gender">Your Gender</label>
			    <div class="input-group">
				 <span class="input-group-text"><i class="bi bi-gender-ambiguous"></i></span>
				 <input type="text" name="gender" value="<?php echo $users['gender'];?>" class="border border-dark form-control" placeholder="Your gender"/>
				</div>
			  </div>
			   <div class="my-2">
			    <label for="location">Your Location</label>
			    <div class="input-group">
				 <span class="input-group-text"><i class="bi bi-geo-alt"></i></span>
				 <input type="text" name="location" value="<?php echo $users['location']; ?>" class="border border-dark form-control" placeholder="City or Town"/>
				</div>
				 <div class="my-2">
			    <label for="about">Your Story</label>
			    <div class="input-group">
				 <span class="input-group-text"><i class="bi bi-question"></i></span>
				 <textarea name="about" class="border border-dark form-control" placeholder="Tell us your story"><?php echo $users['about']; ?></textarea>
				</div>
			  </div>
			  </div>
			  <div class="my-3">
			     <div class="my-1">
				    <img class="float-start" src="<?php echo $users['profile_image'];?>" style="height:50px;width:50px;border-radius:50%;"/>
				 </div>
			    <label for="image">Upload Profile Image</label>
			    <input type="file" name="image" accept=".jpg,.jpeg,.png" class="form-control"/>
			  </div>
			  <div class="my-2 text-center">
			    <input type="submit" name="save" value="Save Profile Details" class="btn btn-lg btn-primary"/>
			  </div>
			</form>
			<?php
				  }
			    }
			   ?>
			</div>
		 </div>
		</div>
	 </div>
 <!-- JavaScript Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
 </body>
</html>
