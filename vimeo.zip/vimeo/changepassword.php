<?php 
session_start();
include 'functions/dbconnection.php';
?>
<!doctype html>
<html lang="en">
 <head>
    <?php include 'includes/header.php'; ?>
 </head>
 <body>
    <?php include 'includes/navigation.php';?>
   <div class="container mt-5">
    <div class="row">
        <div class="col-md-6 mx-auto mt-5">
        <h2 class="text-center">Create New Password</h2>
              <div class="my-3 text-center">
                <?php include 'functions/changepassword.php';?>
              </div>
              <div class="card -card-body p-4">
            <form action="changepassword.php" method="post">
                <div class="my-3">
                  <label for="email">Your Email</label>
                  <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                    <input type="text" name="email" class="form-control border border-dark" placeholder="Enter your email"/>
                  </div>
                </div>
                <div class="my-3">
                  <label for="newpassword">New Password</label>
                  <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-key"></i></span>
                    <input type="password" name="password" class="form-control border border-dark" placeholder="New Password"/>
                  </div>
                </div>
                <div class="my-3 text-center">
                    <button type="submit"  name="submit" class="btn btn-lg btn-success">Save New Password</button>
                </div>
            </form>
            </div>
        </div>
    </div>
   </div>
<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
 </body>
</html>