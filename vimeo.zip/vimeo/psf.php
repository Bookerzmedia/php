<?php
session_start();
 if(isset($_SESSION['id'])){
   header('Location:dashboard.php');
 }
?>
<!doctype html>
<html lang="en">
 <head>
    <?php include 'includes/header.php'; ?>
 </head>
 <body>
    <?php include 'includes/navigation.php';?>
	<div class="container my-5">
	 <div class="row">
	    <div class="col-md-7 mx-auto">
		 <h2 class="text-center">Password Forget</h2>
		 <h4 class="text-center my-5">Enter Your Email or Username</h4>

		 <div class="card card-body border border-info">
		      <div class="my-3 text-center">
			    <?php include 'functions/psf.php'; ?>
			  </div>
			<form action="psf.php" method="post">
			 <div class="my-3">
			    <label for="emailuser">Email Address or Username</label>
			    <div class="input-group">
				<span class="input-group-text"><i class="bi bi-question"></i></span>
				<input type="text" name="emailuser" class="form-control border border-dark" placeholder="Email address or Username"/>
				</div>
			 </div>
			 <div class="my-3 text-center">
			    <input type="submit" value="Submit" name="submit" class="btn btn-success btn-lg"/>
			 </div>
			</form>
		 </div>
		</div>
	 </div>
	</div>
  <!-- JavaScript Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
 </body>
</html>
